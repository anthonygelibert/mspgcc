The giveio driver is required to use the HIL.dll on Windows NT/2k/XP.

Use the batch files to load or unload the driver. The driver is
copied to the windows directory to avaoid problems when this directory
is moved or removed.

part of http://mspgcc.sf.net
 chris <cliechti@gmx.net>
