pySerJTAG
---------

This is the firmware for the Serial-JTAG adapter. It uses its own serial
protocol. (GDB compatible firmware is in developement too) It's compiled to
be run on a F13x or F14x MSP430 processor, F149 recomended for the cloning
function.

Hardware as proposed in the schematics, found on http://mspgcc.sf.net

Features
--------
- up- and download to RAM, peripherals and Flash
- erase Flash by segment, MAIN only or all
- execute at address
- stop the CPU at any time
- reset CPU (PUC)
- cloning function -> copy a user programm stored on the adapter to the
  target MSP. Cloning is started by pressing the start button.

Installation
------------

Close the BSL enable jumper and use pyBSL to download the firmware. It is
recomended that you open the jumper after programing to avoid accidental
deletation afterwards.

Developer Notes
---------------

The firmware is located in the top 8k of the Flash. This leaves the rest of
the Flash free for user programs for the cloning function.

A 13x series MCU is choosen as target so that the HW multiplier is not used
and that not too much ram is used.
The resulting binary can be downloaded to any F13x and F14x CPU (min 8k
Flash required)

The data for the cloning function can be stored anywhere in the Flash, the
address is determined by the pyserjtag software. A pointer to that data
is stored at 0x1000 (INFO-Flash).
The data block consists of a word that selects the Flash erase mode. This
allows to erase the target's main memory only, e.g. to preserve callibration
data in the INFO-Flash. Then a word indicates the number of entries in the
following table table. The table is organized in segments. Each segment has
a start address and a size in words.

Information
-----------

Please read the docs in the pyserjtag package. That package contains the PC
side software.

This is not a finished software ;-) the features listed above are supported,
but the verify of the cloning function is not yet working correctly. The
jumpers are not yet used, selection of baudrate is planned. Yet more things
to come...

The firmware is/will be flexible enough to support 4, 6 and 8 MHz crystals
as well as F123 CPU (without cloning).

Pins for JTAG fuse blowing are reserved, but currently not used.

chris <cliechti@gmx.net>
