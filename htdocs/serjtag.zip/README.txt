pySerJTAG
---------

Introduction
------------

This is the firmware for the Serial-JTAG adapter.
It's compiled to be run on a F13x or F14x MSP430 processor,
F149 recomended for the cloning function.

HW as proposed in the schematics, found on http://mspgcc.sf.net

Features
--------
- up- and download to RAM, peripherals and Flash
- erase Flash by segment, MAIN only or all
- execute at address
- stop the CPU at any time
- reset CPU (PUC)
- cloning function -> copy a user programm stored on the adapter to the
  target MSP. Cloning is started by pressing the start button.

Installation
------------

Close the BSL enable jumper and use pyBSL to download the firmware.
It is recomended that you open the jumper after programming to avoid
accidental deletation afterwards.

Information
-----------

This is not a finished software ;-) the features listed above are supported,
but the verify of the cloning function is not yet working correctly. The
jumpers are not yet used, selection of baudrate is planned. Yet more things
to come...

The protocol over the serial line is not fixed. It's likely that it
changes or that an alternative protocol is added. (GDB remote serial
protocol planed).

The firmware is/will be flexible enough to support 4, 6 and 8 MHz crystals
as well as F123 CPU (without cloning).

Pins for JTAG fuse blowing are reserved, but currently not used.

chris <cliechti@gmx.net>
